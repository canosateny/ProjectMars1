﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using RelevantCodes.ExtentReports;
using SpecflowPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using static NUnit.Core.NUnitFramework;
using static SpecflowPages.CommonMethods;


namespace SpecflowTests.AcceptanceTest
{
    [Binding]
    public sealed class AddProfileDetails :Utils.Start
    {
        // For additional details on SpecFlow step definitions see https://go.specflow.org/doc-stepdef

        private readonly ScenarioContext context;

        public AddProfileDetails(ScenarioContext injectedContext)
        {
            context = injectedContext;
        }

        [Given(@"I have entered Profile details")]
        public void GivenIHaveEnteredProfileDetails()
        {
            //  ScenarioContext.Current.Pending();
            Thread.Sleep(5000);
            //Click to display the FirstName and LastName
            IWebElement dropdownIcon = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div[1]/i"));
            dropdownIcon.Click();
            Thread.Sleep(500);
            //Locate and Enter First Name
            IWebElement FirstnameTextbox = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div[2]/div/div[1]/input[1]"));
            FirstnameTextbox.Clear();
            FirstnameTextbox.SendKeys("Testing");
            Thread.Sleep(500);
            //Locate and Enter Last Name
            IWebElement LastnameTextbox = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div[2]/div/div[1]/input[2]"));
            LastnameTextbox.Clear();
            LastnameTextbox.SendKeys("ForSample");
            Thread.Sleep(500);

            //Click on Language Tab
            IWebElement LanguageIcon = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[1]/a[1]"));
            LanguageIcon.Click();
            Thread.Sleep(1000);
            //Locate and Click on Add New button
            IWebElement LanguageAddNew = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/table/thead/tr/th[3]/div"));
            LanguageAddNew.Click();
            Thread.Sleep(500);
            //Add language
            IWebElement AddLanguage = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/div/div[1]/input"));
            AddLanguage.SendKeys("Spanish");
            Thread.Sleep(500);
            //Choose Language Level
            var LanguageList = driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/div/div[2]/select"));
            var selectElement = new SelectElement(LanguageList);
            selectElement.SelectByValue("Basic");
            //Click on Add button
            IWebElement AddNewLanguage = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/div/div[3]/input[1]"));
            AddNewLanguage.Click();
            Thread.Sleep(5000);

            //Verify the Language record is added
           
            try
            {

                IWebElement RecLanguage = driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/form/div[2]/div/div[2]/div/table/tbody/tr/td[1]"));
                string expectedValueLang = "Spanish";
                string actualValueLang = RecLanguage.Text;

                Thread.Sleep(3000);
                if (expectedValueLang == actualValueLang)
                {
                    //Console.WriteLine("Pass - Language Record is added");
                    ////Assert.AreEqual("expectedProfileName", ActualProfileName);
                    LogResults(LogStatus.Pass, "Test Passed, Added a Language record Successfully");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "LanguageAdded");

                }

                else
                {
                    //Console.WriteLine("Fail - Language Record is not added");
                    LogResults(LogStatus.Fail, "Test Failed");
                }
                   

            }
            catch (Exception e)
            {
                //Console.WriteLine("Test Failed, No Record found for Language catch");
                LogException(LogStatus.Fail, "Test Failed", e);
            }


            //Click on Skill Tab
            IWebElement SkillsIcon = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[1]/a[2]"));
            SkillsIcon.Click();
            //Click on AddNew
            IWebElement AddnewSkillIcon = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[3]/div/div[2]/div/table/thead/tr/th[3]/div"));
            AddnewSkillIcon.Click();
            //Add Skill
            IWebElement AddSkill = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[3]/div/div[2]/div/div/div[1]/input"));
            AddSkill.SendKeys("Automation123");
            //Choose Skill Level
            var SkillLevel = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[3]/div/div[2]/div/div/div[2]/select"));
            var skill = new SelectElement(SkillLevel);
            skill.SelectByValue("Beginner");
            //Click Add button
            IWebElement AddSkillButton = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[3]/div/div[2]/div/div/span/input[1]"));
            AddSkillButton.Click();
            Thread.Sleep(5000);

            //Verify the Skills record is added

            try
            {

                IWebElement recSkil = driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/form/div[3]/div/div[2]/div/table/tbody/tr/td[1]"));
                string expectedValueSkill = "Automation123";
                string actualValueSkill = recSkil.Text;

                Thread.Sleep(3000);
                if (expectedValueSkill == actualValueSkill)
                {
                    //Console.WriteLine("Pass - Skills record is added");
                    //Assert.AreEqual("expectedProfileName", ActualProfileName);
                    LogResults(LogStatus.Pass, "Test Passed, Added a Skills record Successfully");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "SkillsAdded");
                }

                else
                {
                    //Console.WriteLine("Fail - Skills record is not added");
                    LogResults(LogStatus.Fail, "Test Failed");
                }
                    

            }
            catch (Exception e)
            {
                //Console.WriteLine("Test Failed, No Record found for Skills catch");
                LogException(LogStatus.Fail, "Test Failed", e);
            }

            //Click on Education Tab
            IWebElement EducationIcon = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[1]/a[3]"));
            EducationIcon.Click();
            //Locate and Enter College/Uni Name
            IWebElement AddEducationButton = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/table/thead/tr/th[6]/div"));
            AddEducationButton.Click();
            //Select Country of College/Unit
            IWebElement University = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[1]/div[1]/input"));
            University.SendKeys("University of Auckland");
            var Country = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[1]/div[2]/select"));
            var CountryName = new SelectElement(Country);
            CountryName.SelectByValue("New Zealand");
            //Select Title
            var Title = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[1]/select"));
            var TitleName = new SelectElement(Title);
            TitleName.SelectByValue("B.Sc");
            //Locate and Enter Degree
            IWebElement Degree = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[2]/input"));
            Degree.SendKeys("Maths");
            //Year of Graduation
            var Year = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[2]/div[3]/select"));
            var YearofGraduate = new SelectElement(Year);
            YearofGraduate.SelectByValue("2017");
            //Click on Add for Education
            IWebElement AddEducation = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/div/div[3]/div/input[1]"));
            AddEducation.Click();
            Thread.Sleep(5000);

            //Verify the Education record is added

            try
            {

                IWebElement recEdu = driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/form/div[4]/div/div[2]/div/table/tbody/tr/td[4]"));
                string expectedValueEdu = "Maths";
                string actualValueEdu = recEdu.Text;

                Thread.Sleep(3000);
                if (expectedValueEdu == actualValueEdu)
                {
                    //Console.WriteLine("Pass - Education record is added");
                    ////Assert.AreEqual("expectedProfileName", ActualProfileName);
                    LogResults(LogStatus.Pass, "Test Passed, Added a Education record Successfully");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "EducationAdded");
                }

                else
                {
                    //Console.WriteLine("Fail - Education record is not added");
                    LogResults(LogStatus.Fail, "Test Failed, Education record is not added");
                }
                   

            }
            catch (Exception e)
            {
                //Console.WriteLine("Test Failed, No Record found for Education catch");
                LogException(LogStatus.Fail, "Test Failed", e);
            }

            //Click on Certifications
            IWebElement CertificationIcon = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[1]/a[4]"));
            CertificationIcon.Click();
            //Locate and click for 'Certificate or Award'
            IWebElement AddCertificate = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/table/thead/tr/th[4]/div"));
            AddCertificate.Click();
            //Enter value for 'Certificate or Award'
            IWebElement Certificate = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[1]/div/input"));
            Certificate.SendKeys("ISTQB Advanced Level");
            //Locate, Click and Enter value for 'Certified From'
            IWebElement CertifiedFrom = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[2]/div[1]/input"));
            CertifiedFrom.SendKeys("ANZTB");
            //Enter Year
            var CertificationYear = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[2]/div[2]/select"));
            var YearCertified = new SelectElement(CertificationYear);
            YearCertified.SelectByValue("2018");
            //Click on Add for 'Certifications'
            IWebElement AddCertified = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/div/div[3]/input[1]"));
            AddCertified.Click();
            Thread.Sleep(5000);

            //Verify the Certification record is added

            try
            {

                IWebElement recCerti = driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[3]/form/div[5]/div[1]/div[2]/div/table/tbody/tr/td[1]"));
                string expectedValueCerti = "ISTQB Advanced Level";
                string actualValueCerti = recCerti.Text;

                Thread.Sleep(3000);
                if (expectedValueCerti == actualValueCerti)
                {
                    /*Console.WriteLine("Pass - Certificate record is added")*/;
                    //Assert.AreEqual("expectedProfileName", ActualProfileName);
                    LogResults(LogStatus.Pass, "Test Passed, Added a Certificate record Successfully");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "CertificateAdded");
                }

                else
                {
                    //Console.WriteLine("Fail - Certificate record is not added");
                    LogResults(LogStatus.Fail, "Test Failed, Certificate record is not added");
                }
                    

            }
            catch (Exception e)
            {
                //Console.WriteLine("Test Failed, No Record found for Certificate catch");
                LogException(LogStatus.Fail, "Test Failed", e);
            }

            Thread.Sleep(3000);

            //Save the Profile with all new records
            IWebElement SaveDetails = driver.FindElement(By.XPath("//*[@id=\"account-profile-section\"]/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div[2]/div/div[2]/button"));
            SaveDetails.Click();

        }

        [Then(@"I can view the seller's details on the profile page")]
        public void ThenICanViewTheSellerSDetailsOnTheProfilePage()
        {
            //ScenarioContext.Current.Pending();
          
            try
            {
                
                IWebElement ProfileName = driver.FindElement(By.XPath("/html/body/div[1]/div/section[2]/div/div/div/div[2]/div/div/div/div/div/div[2]/div/div/div[1]"));
                string ActualProfileName = ProfileName.Text;
                string expectedProfileName = "Testing ForSample";

                Thread.Sleep(5000);
                if (expectedProfileName == ActualProfileName)
                {
                    Console.WriteLine("Pass - UserProfileName is displayed");
                    //Assert.AreEqual("expectedProfileName", ActualProfileName);
                    LogResults(LogStatus.Pass, "Test Passed, UserProfileName is displayed");
                    SaveScreenShotClass.SaveScreenshot(Driver.driver, "ProfileAdded");

                }

                else
                {
                    //Console.WriteLine("Fail - UserProfileName is not displayed");
                    LogResults(LogStatus.Fail, "Test Failed, UserProfile record is not added");
                }
                    

            }
            catch (Exception e)
            {
                //Console.WriteLine("Test Failed, No Record found catch");
                LogException(LogStatus.Fail, "Test Failed", e);
            }

            


        }

    }
}
