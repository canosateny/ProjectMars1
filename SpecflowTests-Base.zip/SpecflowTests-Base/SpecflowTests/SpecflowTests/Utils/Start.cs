﻿using RelevantCodes.ExtentReports;
using SpecflowPages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using TechTalk.SpecFlow;
using static SpecflowPages.CommonMethods;

namespace SpecflowTests.Utils
{
    public class Start : Driver
    {
        public ExtentReports extentReports;
        public ExtentTest test;

        [BeforeScenario]
        public void SetUp()
        {
            //Launch the browser
            Initialize();
            Thread.Sleep(500);
            _ = new ConstantUtils();
            //Instantiate ExtentReport
            extentReports = CommonMethods.GetExtentReports(extentReports);
            //Start Test
            test = extentReports.StartTest(ScenarioContext.Current.ScenarioInfo.Title);
            //Call the Login Class            
            SpecflowPages.Utils.LoginPage.LoginStep();
        }

        public void LogResults(LogStatus logStatus, string description)
        {
            test.Log(logStatus, description);
        }

        public void LogException(LogStatus logStatus, string description, Exception exception)
        {
            test.Log(logStatus, description, exception);
        }

        [AfterScenario]
        public void TearDown()
        {

            Thread.Sleep(500);
            // Screenshot
            string img = SaveScreenShotClass.SaveScreenshot(Driver.driver, "Report");
            CommonMethods.LogResult(test, img);

            // end test. (Reports)
            extentReports.EndTest(test);

            // calling Flush writes everything to the log file (Reports)
            extentReports.Flush();

            //Close the browser
            Close();
        }

    }
}
