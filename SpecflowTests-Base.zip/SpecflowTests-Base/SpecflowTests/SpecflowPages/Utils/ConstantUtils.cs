﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpecflowPages
{
    public class ConstantUtils
    {
        readonly string projectDirectory;
        public static string screenshotPath;
        public static string reportsPath;
        public static string configPath;
        public ConstantUtils()
        {
            this.projectDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.FullName;
            SetScreenshotPath();
            SetExtentReportsPath();
            MapConfigPath();
        }

        //Base Url
        public static string Url = "http://www.skillswap.pro/";
        private void SetScreenshotPath()
        {
            screenshotPath = System.IO.Path.Combine(projectDirectory, @"C:\Personal\Teny\IC\SpecflowTests-Base\SpecflowTests-Base\TestResults\Screenshot\");
            DirectoryInfo di = new DirectoryInfo(screenshotPath);
            if (!di.Exists)
            {
                di.Create();
            }
        }

        private void SetExtentReportsPath()
        {
            var reportsUri = System.IO.Path.Combine(projectDirectory, @"C:\Personal\Teny\IC\SpecflowTests-Base\SpecflowTests-Base\TestResults\TestReport\");
            DirectoryInfo di = new DirectoryInfo(reportsUri);
            if (!di.Exists)
            {
                di.Create();
            }
            reportsPath = reportsUri + "TestAutomationReport.html";
        }

        private void MapConfigPath()
        {
            string currentPath = Path.GetDirectoryName(Path.GetDirectoryName(System.IO.Directory.GetCurrentDirectory()));
            string solutionPath = currentPath.Substring(0, currentPath.LastIndexOf("SpecflowTests"));
            configPath = System.IO.Path.Combine(projectDirectory, @"SpecflowPages\ReportXML.xml");
        }
    }
}
